'''
    根据输入的数据集标记各属性的值，学习得到具体分类参数
    进行逻辑回归，求得系数w
'''

import numpy as np
import math
import matplotlib.pyplot as plt

class calculate_neww:
    '''
    def __init__(self,m,n,X,Y):创建类中的函数，也叫方法
    这种形式在定义方法时，就直接给定了参数，且属性值不允许为空。实例化时，直接传入参数
    self为形式参数
    '''

    def __init__(self,m,n,X,Y):
        self.m = m
        self.n = n
        self.X = X
        self.Y = Y
        self.w = np.ones((n,1))  # 构造n行1列全为1的矩阵
        self.wd = np.zeros((n,1))  # 构造n行1列全为0的矩阵

    def differentialfunc(self):#求损失函数的导数
        tempa = np.zeros((self.m,1))
        for i in range(0,self.m):   # range(start, stop[, step])，分别是起始、终止和步长,将由range生成的数据集依次赋给i
            for j in range(0,self.n):
                tempa[i] = self.X[i][j]*self.w[j] + tempa[i]
        for j in range(0,self.n):
            tempb = 0
            for i in range(0,self.m):
                tempb = tempb - self.Y[i]*self.X[i][j] + self.X[i][j]*math.pow(math.e,tempa[i])/(1+math.pow(math.e,tempa[i]))
            self.wd[j] = tempb/self.m

    def lossfunc(self):    # 求损失函数，优化的目的是尽可能最小化损失函数
        tempa = np.zeros((self.m, 1))
        for i in range(0, self.m):
            for j in range(0, self.n):
                tempa[i] = self.X[i][j] * self.w[j] + tempa[i]
        loss = 0
        for i in range(0,self.m):
            loss = loss + self.Y[i]*tempa[i] - math.log(1 + math.pow(math.e,tempa[i]))
        return loss

    def gradientdescent(self):#梯度优化的过程
        u = 1000
        lastloss = self.lossfunc()#当前系数对应的损失函数的值
        k = 0.05#步长
        count = 0
        while u > 0.005:
            #print(k)
            self.differentialfunc()#对损失函数求导
            for i in range(0,self.n):
                self.w[i] = self.w[i] - k*self.wd[i]#按照梯度下降的方向改变系数值
            nowloss = self.lossfunc()
            u = math.fabs(nowloss - lastloss)
            #if nowloss - lastloss > 0.05:
            #    k = k/2
            lastloss = nowloss
            #print(nowloss)

        '''
            用测试集来验证学习效果,思路:
            先用不同的颜色标记出正例样本点与反例样本点
            再将学习结果用直线的形式表现出来，直观观察分类结果
        '''
    def test(self,m,n,X,Y):#测试学习效果的函数
        self.m = m
        self.n = n
        self.X = X
        self.Y = Y
        plt.plot([0,-(self.w[2]/self.w[0])],[-(self.w[2]/self.w[1]),0])#逻辑回归的结果，用一条直线表示
        for i in range(0,self.m):
            if self.Y[i] == 0:
                plt.scatter(self.X[i][0], self.X[i][1], color='red')
            else:
                plt.scatter(self.X[i][0], self.X[i][1], color='blue')
        plt.show()

    def differentialfuncwithpunish(self,hyper): # 求带正则的损失函数的导数
        self.differentialfunc()
        for i in range(0,self.n):
            self.wd[i] = self.wd[i] + hyper*self.wd[i]

    def lossfunwithpunish(self,hyper): # 求带正则的损失函数
        partloss = self.lossfunc()
        temp = 0
        for i in range(0,self.n):
            temp = temp + hyper*self.w[i]*self.w[i]/2
        loss = temp + partloss
        return loss

    def gradientdescentwithpunish(self,hyper): # 用带正则的梯度下降法求损失函数
        '''
        带惩罚项的损失函数梯度下降过程
        这里在损失函数的计算，损失函数的求导中，要考虑到惩罚项
        :param hyper: 超参数，调节惩罚项的权重
        :return: 无
        '''
        u = 1000
        lastloss = self.lossfunwithpunish(hyper)
        k = 0.05  # 步长
        while u > 0.000005:
            self.differentialfuncwithpunish(hyper)
            for i in range(0,self.n):
                self.w[i] = self.w[i] - k*self.wd[i]
            nowloss = self.lossfunwithpunish(hyper)
            u = math.fabs(nowloss - lastloss)
            #print('u = ', u)
            lastloss = nowloss
            #print(nowloss)

    def testwithpunish(self,m,n,X,Y):
        self.m = m
        self.n = n
        self.X = X
        self.Y = Y
        plt.plot([0, -(self.w[2] / self.w[0])], [-(self.w[2] / self.w[1]), 0])
        for i in range(0, self.m):
            if self.Y[i] == 0:
                plt.scatter(self.X[i][0], self.X[i][1], color='red')
            else:
                plt.scatter(self.X[i][0], self.X[i][1], color='blue')
        plt.show()


