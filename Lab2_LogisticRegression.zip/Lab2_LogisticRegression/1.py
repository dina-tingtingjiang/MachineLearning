# 实现UCI的美国人口收入数据集逻辑回归的主程序
import pandas as pd
from datacleaning import data_cleaning
import numpy as np
from calculateneww import calculate_neww

data = pd.read_csv('adult.data')
data_cleaning_ins = data_cleaning(data)
x_point,y_value = data_cleaning_ins.begin_cleaning()  #得到了一个数据集
dimension = 8  # 维度
trainnumber = 1000  # 在其中取1000个样本作为训练集
x_point_train = np.array(x_point[0:trainnumber,0:dimension])  # 生成数组
y_value_train = np.array(y_value[0:trainnumber])
# 在calculate_neww.py中进行逻辑回归学习，学得回归系数W
calculator = calculate_neww(trainnumber,dimension,x_point_train,y_value_train)
calculator.gradientdescent() #用梯度下降法计算
w = calculator.w  # 获得逻辑回归的系数矩阵
#assert isinstance(w, object)
print(w)
# 再从数据集选取1000个样本点作为测试集来测试学习效果
x_point_test = np.array(x_point[trainnumber:2*trainnumber,0:dimension])
y_value_test = np.array(y_value[trainnumber:2*trainnumber])


# 由理论分析可知，如果>0,根据逻辑回归分类结果，y就应该标记为0，否则为1
# 这个结果与实际情况比较，就能得出学习效果
accuratenumber = 0
for i in range(0,trainnumber):
    loss = 0
    for j in range(0,dimension):
        loss = loss + x_point_test[i][j]*w[j]
    if (loss>=0 and (y_value_test[i] == 1)) or (loss<0 and (y_value_test[i] == 0)):
        accuratenumber = accuratenumber + 1
print('accuratenumber=', accuratenumber)


import pandas as pd
import numpy as np

class data_cleaning:
    def __init__(self,data):
        self.data = data
    def drop_somecolumns(self):
        """
        除去一些没有序关系的值
        :return:
        """
        self.data.columns = ['age', 'workclass', 'fnlwgt', 'education', 'education-num', 'martial-status', 'occupation',
                        'relationship', 'race', 'sex', 'capital-gain', 'capital-loss', 'hours-per-week',
                        'native-country', 'income']
        self.data = self.data.drop(labels='workclass', axis=1)
        self.data = self.data.drop(labels='fnlwgt', axis=1)
        self.data = self.data.drop(labels='education', axis=1)
        self.data = self.data.drop(labels='occupation', axis=1)
        self.data = self.data.drop(labels='relationship', axis=1)
        self.data = self.data.drop(labels='native-country', axis=1)
        self.data = self.data.drop(labels='martial-status',axis=1)
    def funcsex(self,x):
        x = x.strip()
        if x == 'Female':
            return 0
        else:
            return 1
    def funcrace(self,x):
        x = x.strip()
        if x == 'White':
            return 0
        if x == 'Asian-Pac-Islander':
            return 1
        if x == 'Amer-Indian-Eskimo':
            return 2
        if x == 'Other':
            return 3
        if x == 'Black':
            return 4
    def funincome(self,x):
        x = x.strip()
        if x == '<=50K':
            return 0
        else:
            return 1
    def begin_cleaning(self):
        self.drop_somecolumns()
        self.data['sex'] = self.data['sex'].apply(lambda x:self.funcsex(x))
        self.data['race'] = self.data['race'].apply(lambda  x:self.funcrace(x))
        self.data['income'] = self.data['income'].apply(lambda x:self.funincome(x))
        x_point = np.array(self.data)
        x_point = np.delete(x_point,7,axis=1)#在原来的矩阵中删除最后一项收入项。
        y_value = np.array(self.data['income'])
        rownumber = x_point.shape[0]
        colnumber = x_point.shape[1]
        print('rownumber = ',rownumber)
        #print('max = ',x_point.max(axis=0))
        x_point = np.array(x_point,dtype=float)
        count = 0
        #对一些取值过大的属性进行缩放，防止运算过程中产生溢出
        for i in range(0,rownumber):
            x_point[i][0] = float(x_point[i][0])/10
            x_point[i][1] = x_point[i][1]/10.0
            x_point[i][2] = x_point[i][2]
            x_point[i][3] = x_point[i][3]
            x_point[i][4] = x_point[i][4]/100000.0
            x_point[i][5] = x_point[i][5]/10000.0
            x_point[i][6] = x_point[i][6]/100.0
        B = np.ones(rownumber)
        x_point = np.insert(x_point,colnumber,values=B,axis=1)
        return x_point,y_value

