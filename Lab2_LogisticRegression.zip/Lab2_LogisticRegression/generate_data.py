'''
自动生成训练集
利用numpy中的函数生成数据集
数据集中的每一个样本的两个属性值符合二元高斯分布
'''
import numpy as np
import random
import matplotlib as pl


class data_genera:
    def generator(self,number,posnumber,mean_pos,mean_neg,cov11,cov12,cov21,cov22):
        """
        按照二维高斯分布来自动生成数据集
        :param number: 数据集样本数量
        :param posnumber: 样本中正例数量
        :param mean_pos: 正例样本的属性均值
        :param mean_neg: 反例样本的属性均值
        :param cov11: cov(正例样本集，正例样本集)
        :param cov12: cov（正例样本集,反例样本集)
        :param cov21: cov(反例样本集，正例样本集)
        :param cov22: cov(反例样本集，反例样本集)
        :return: x_point是样本集的属性值矩阵，y_value是生成样本的真实标记
        """

        '''
         range() 函数：（1）表示的是左闭右开区间
                      （2）它接收的参数必须是整数，可以是负数，但不能是浮点数等其它类型
                      （3）它是不可变的序列类型，可以进行判断元素、查找元素、切片等操作，但不能修改元素
                      （4）它是可迭代对象，却不是迭代器。
        '''
        x_point = [] # 样本集的属性值矩阵
        y_value = [] #生成样本的真实标记
        for i in range(0,posnumber): # 样本中正例数量

            '''
            依据均值和协方差生成生成一个多元正态分布矩阵(计算协方差别忘了转置)
            mean_pos: 正例样本的属性均值
            mean_neg: 反例样本的属性均值
            '''
            tempxa,tempxb = np.random.multivariate_normal([mean_pos,mean_pos],[[cov11,cov12],[cov21,cov22]])
            #  append():增加元素对象
            x_point.append([tempxa,tempxb,1])
            y_value.append(1)
        for i in range(0,number-posnumber):
            tempxa,tempxb = np.random.multivariate_normal([mean_neg,mean_neg],[[cov11,cov12],[cov21,cov22]])
            x_point.append([tempxa,tempxb,1])
            y_value.append(0)
        for i in range(0,number):  # 将正例样本与反例样本随机混合
            j = random.randint(0,number-1)
            temppoint = x_point[i]
            x_point[i] = x_point[j]
            x_point[j] = temppoint
            tempvalue = y_value[i]
            y_value[i] = y_value[j]
            y_value[j] = tempvalue
        return x_point,y_value

