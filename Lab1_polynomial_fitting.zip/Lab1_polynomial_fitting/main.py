import numpy as np
import math
import matplotlib.pyplot as plt
global sample_n # 样本数量
global poly_degree # 多项式次数
sample_n = 10
poly_degree = 9

'''
生成样本数据
样本x为[0,1]上均匀的sample_n个点
样本y值为sin(2Πx)的值，再加上均值为mu，标准差为sigma的高斯噪声
'''

'''
np.arange()的使用规则：
函数返回一个有终点和起点的固定步长的排列，如[1,2,3,4,5]，起点是1，终点是6，步长为1
当有三个参数时，第一个参数为起点，第二个参数为终点，第三个参数为步长。其中步长支持小数
'''

def GetData(mu, sigma):
    train_x = np.arange(0, 1, 1 / sample_n) # 步长为1 / sample_n
    gauss_noise = np.random.normal(mu, sigma, sample_n)
    train_y = np.sin(train_x * 2 * np.pi) + gauss_noise
    return train_x, train_y

'''
    求得损失函数E(w)
    E(w) = 1/2 * (Xw - Y)^{T} . (Xw - Y)
'''
def loss(train_x, train_y, w):
    X = GetMatrixX(train_x) # 获得train_x的矩阵
    Y = train_y.reshape((sample_n, 1)) # 根据train_y变换出sample_n行，1列的矩阵
    temp = X.dot(w) - Y  # dot():矩阵相乘
    loss = 1/2 * np.dot(temp.T, temp)
    return loss

'''
获取X矩阵
由于生成的得到的样本数据是一维向量，要预处理成为矩阵X(维度为sample_n * (poly_degree + 1))
'''
def GetMatrixX(train_x):
    X = np.zeros((sample_n, poly_degree + 1)) # 用0填充的(sample_n, poly_degree + 1)矩阵
    for i in range(sample_n): # 数据范围在0-0.9的一维向量
        row_i = np.ones(poly_degree + 1) * train_x[i] # np.ones：返回一个全1的n维数组
        nature_row = np.arange(0, poly_degree+1)
        row_i = np.power(row_i, nature_row) # 算得row_i的nature_row次方
        X[i] = row_i
    return X


# 调用numpy.polyfit()拟合数据
def np_polyfit(train_x, train_y):
    w = np.polyfit(train_x, train_y, poly_degree) # 用poly_degree次多项式拟合，返回系数
    poly = np.poly1d(w) # 得到多项式系数，按照阶数从高到低排列
    return poly # 显示多项式poly

''' 
不加惩罚项，令损失函数导数等于0，求此时的w
[::-1]： 代表从全列表倒序取
np.linalg.inv:求逆矩阵
'''

def lsm_loss(train_x, train_y):  #不加惩罚项，令损失函数导数等于0，求此时的w
    X = GetMatrixX(train_x)
    Y = train_y.reshape((sample_n, 1))
    w = np.linalg.inv(np.dot(X.T, X)).dot(X.T).dot(Y)
    poly = np.poly1d(w[::-1].reshape(poly_degree + 1))
    return poly

'''
加惩罚项，系数为lam，令损失函数导数等于0，求此时的w
np.eye:可生成对角阵
X.shape[1]读取矩阵的列长度
'''

def lsm_punished_loss(train_x, train_y, lam): #加惩罚项，系数为lam，令损失函数导数等于0，求此时的w
    X = GetMatrixX(train_x)
    Y = train_y.reshape((sample_n, 1))
    w = np.linalg.inv(np.dot(X.T, X) + lam * np.eye(X.shape[1])).dot(X.T).dot(Y)
    poly = np.poly1d(w[::-1].reshape(poly_degree + 1))
    return poly

'''
        加惩罚项，系数为lam，对损失函数用梯度下降，当损失函数收敛时，得到此时的w
        最多循环轮次epoch，下降步长eta，迭代误差eps
        np.ones:ones()返回一个全1的n维数组
        np.arange()函数返回一个有终点和起点的固定步长的排列
        [:i+1]:取第i＋1列数据
'''
def descent_gradient(train_x, train_y, lam, epoch, eta, eps):
    w = np.power(10 * np.ones((1, poly_degree + 1)), -np.arange(0, poly_degree + 1)).T
    w = 0.1 * np.ones((poly_degree + 1, 1))
    X = GetMatrixX(train_x)
    Y = train_y.reshape((sample_n, 1))
    epoch_list = np.zeros(epoch)
    loss_list = np.zeros(epoch)

    for i in range(epoch):
        old_loss = abs(loss(train_x, train_y, w))
        partial_deriv = X.T.dot(X).dot(w) - X.T.dot(Y) + lam * w # 函数E对w的偏导
        print(partial_deriv)
        w = w - eta * partial_deriv
        new_loss = abs(loss(train_x, train_y, w))
        epoch_list[i] = i
        loss_list[i] = new_loss
        print(new_loss)
        if(abs(new_loss - old_loss) < eps):
            epoch_list = epoch_list[:i+1]
            loss_list = loss_list[:i+1]
            break
    poly = np.poly1d(w[::-1].reshape(poly_degree + 1)) # [::-1]： 代表从全列表倒序取
    return poly, epoch_list, loss_list

'''
加惩罚项，系数为lam，对损失函数用共轭梯度法，循环迭代m+1次，得到此时的w
迭代误差eps
'''
def conjugate_gradient(train_x, train_y, lam, eps): #加惩罚项，系数为lam，对损失函数用共轭梯度法，循环迭代m+1次，得到此时的w
    X = GetMatrixX(train_x)
    Y = train_y.reshape((sample_n, 1))
    Q = np.dot(X.T, X) + lam * np.eye(X.shape[1])
    Q.shape = (10, 10)
    w = np.zeros((poly_degree + 1, 1))
    gradient = np.dot(X.T, X).dot(w) - np.dot(X.T, Y) + lam * w
    r = -gradient
    r.shape = (10, 1)
    p = r
    p.shape = (10, 1)
    for i in range(poly_degree + 1):
        a = (r.T.dot(r)) / (p.T.dot(Q).dot(p))
        a.shape = (1,1)
        r_prev = r
        w = w + a * p
        w.shape = (10, 1)
        r = r - (a * Q).dot(p)
        beta= (r.T.dot(r)) / (r_prev.T.dot(r_prev))
        beta.shape = (1, 1)
        p = r + beta * p
    poly = np.poly1d(w[::-1].reshape(poly_degree + 1))
    return poly

'''
    画图像
    train_x：一维观测数据x
    poly_fit：拟合得到的多项式，数据类型为numpy.poly1d
    train_y：一维观测数据y
    title：图像标题
    plt.plot：绘图(b:蓝色，r:红色)
'''
def plt_show(train_x, poly_fit, train_y, title):
    plot1 = plt.plot(train_x, train_y, 's', label='train_data')
    real_x = np.linspace(0, 0.9, 50) # (在0和0.9之间返回均匀间隔的50个数据)
    real_y = np.sin(real_x * 2 * np.pi)
    fit_y = poly_fit(real_x)
    plot2 = plt.plot(real_x, fit_y, 'b', label='fit_result')
    plot3 = plt.plot(real_x, real_y, 'r', label='real_data')
    plt.xlabel('x') # 设置xlabel坐标名
    plt.ylabel('y')
    plt.legend(loc=1) # 设置图列位置：1: ‘upper right'
    plt.title(title)
    plt.show()

train_x, train_y = GetData(0, 0.1) # 获取数据
print(GetMatrixX(train_x).T.dot(GetMatrixX(train_x)))


# numpy.polyfit直接拟合
p1 = np_polyfit(train_x, train_y)
plt_show(train_x, p1, train_y, 'np.polyfit result')
print(p1)


# 不加惩罚项，导数=0
p2 = lsm_loss(train_x, train_y)
plt_show(train_x, p2, train_y, 'lsm without punishment result')
print(p2)

# 加惩罚项，导数=0
lam1 = 0.0005
p3 = lsm_punished_loss(train_x, train_y, lam1)
plt_show(train_x, p3, train_y, 'lsm with punishment result')
print(p3)

# 加惩罚项，梯度下降求loss最小值
lam2 = 0.0001
eta1 = 0.05
epoch1 = 1000000
eps1 = 1e-5
p4, epoch_list, loss_list = descent_gradient(train_x, train_y, lam2, epoch1, eta1, eps1)
plt_show(train_x, p4, train_y, 'lsm with punishment by descent gradient result')
print(p4)

# 输出loss图像
plt.plot(epoch_list, loss_list, 'r')
plt.xlabel('x')
plt.ylabel('y')
plt.title('E(w) loss in descent gradient')
plt.show()

# 加惩罚项，共轭梯度法
lam3 = 0.0005
eps2 = 1e-5
p5 = conjugate_gradient(train_x, train_y, lam3, eps2)
plt_show(train_x, p5, train_y, 'lsm with punishment by conjugate gradient result')
print(p5)

