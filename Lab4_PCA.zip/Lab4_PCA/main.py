import Operation as Bo
import Show as dI
import numpy as np
from Operation import psnr
from Operation import read_faces
from Operation import PCA

# 自己生成数据的测试
dimension = 2
N = 100
data = Bo.generate_data(dimension, number=N)
c_data, rightEigenVector, mean, recon_data = Bo.PCA(data, dimension - 1)
for i in range(dimension-1):
    print("特征值第"+str(i+1)+"大的特征向量:")
    print(rightEigenVector[:, i])
print("Mean vector:")
print(mean)
dI.originVsPCA(dimension, data, recon_data, mean, rightEigenVector)

dimension = 3
N = 100
data = Bo.generate_data(dimension, number=N)
c_data, rightEigenVector, mean, recon_data = Bo.PCA(data, dimension - 1)
for i in range(dimension-1):
    print("特征值第"+str(i+1)+"大的特征向量:")
    print(rightEigenVector[:, i])
print("Mean vector:")
print(mean)
dI.originVsPCA(dimension, data, recon_data, mean, rightEigenVector)


# 图像处理测试
size = (50, 50)
targetDim = 1
data = Bo.read_faces('Image', size=size)
c_data, rightEigenVector, mean, recon_data = Bo.PCA(data, targetDim)
for i in range(targetDim):
    print("特征值第"+str(i+1)+"大的特征向量:")
    print(rightEigenVector[:, i])
print("Mean vector:")
print(mean)


print("信噪比如下：")
for i in range(1,11):
    a = psnr(data[i], recon_data[i])
    print('图', i, '的信噪比: ', a)


dI.drawFace(recon_data, recon_data.shape[1], size)

# 观测降低到不同维度时的psnr变化
dimRange = np.arange(1, 11, 1)
print(data.shape)
dI.psnrChange(data, dimRange)


